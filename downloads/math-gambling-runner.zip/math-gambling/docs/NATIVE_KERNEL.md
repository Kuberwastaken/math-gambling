# Rust and WebAssembly kernel

The accelerated kernel implements **the same selective `mg114-offset-v1` tasks**, not a new exhaustive Booker–Sutherland campaign. It keeps task IDs, all logical counters, hit order and SHA-256 receipts identical. Since 17 September the GitHub verifier also replays with this kernel (`tools/ingest.py --kernel rust`), built from reviewed `main` source inside the workflow. Python remains the independent reference: every reported identity is re-verified in Python by the bridge, every result is checked for task identity and receipt digest, and a deterministic 1-in-256 share of replayed tasks (selected by task-id hash) is replayed again by the Python engine and must match exactly; any disagreement stops the run as an operational failure. Verified records carry `replay_kernel` with the Rust and Python source hashes. The Rust core handles enumeration and sieving; the existing Python runner handles worker budgets, seeds, checkpoints, GitHub login and banking.

## Engines the kernel accepts (17 September)

- `mg114-offset-v1`, version 1: the original 128-row tasks. Receipts unchanged.
- `mg114-offset-v2`, version 2: the same positions in 1024-row tasks (eight aligned v1 tasks). Counters are the sums and hits the concatenation of the eight v1 results; the id is `mg114-offset-v2:ctx:row:block`. This exists purely to cut per-task dispatch, persistence and banking overhead, which dominated end-to-end client time.
- `mg{k}-offset-v1`, version 1, for the other open targets (k in 3..1000 with k ≡ 3 or 6 mod 9, k ≠ 114) on ℓ = 1 contexts only: the exact mirror of `tools/multi_target.py`. The k-specific signed exclusions are dropped (they are optimisations, not correctness), the cube-root offset constants are computed exactly with big integers once per k, and hits carry only `xyz/D/r/q` so digests match the Python target engine.

Rust and Python agree bit-for-bit on the frozen corpus, on random v2 samples across all 81 contexts, and on cross-target samples (`tests/test_native_kernel.py`). The same source builds the WebAssembly module, so the browser accepts the same tasks.

## Run locally

Install Rust through [rustup](https://rustup.rs/), plus Python 3.11 or newer. From this repository (or the new runner source archive):

```sh
python tools/build_native.py
python tools/runner.py --kernel rust --name "Your alias" --github YOUR_USERNAME --workers 4 --minutes 60 --login --submit
```

Choose a worker count your machine supports. On Windows use `py` if `python` is not available. Each worker keeps a Rust process alive across tasks. Leave out `--login --submit` to compute without uploading. The default `--kernel python` remains available without a compiler. Do not share a live checkpoint directory between machines.

## Browser build

```sh
rustup target add wasm32-unknown-unknown
python tools/build_native.py --wasm
node --test tests/test_wasm_kernel.mjs
```

The same Rust library compiles to a small WebAssembly module with a capped JSON interface. Each Web Worker owns an instance. Identities are delivered immediately and independently checked with JavaScript BigInt. A failed load falls back to the original BigInt kernel; an arithmetic trap after starting a task is an error, never a completed negative receipt. No SIMD, threads-in-WASM, SharedArrayBuffer or cross-origin isolation is required.

## Integer bounds

All public input is validated against the fixed 81 contexts before arithmetic. Bounds below are deliberately conservative, not measured maxima:

- `|b|,|c| <= 6,000,000`, `ell <= 25`, `t <= 8191`, `|a| < 200,000,000`.
- The scaled offset numerator is below `2^89`; each norm expression and all intermediate additions fit signed 128 bits (sum of absolute terms below `2^85`).
- Admitted `D <= 8 floor(10^19/54) < 2^61`. Reduced modular products are below `2^122` and fit signed 128 bits. Extended Euclid runs only on reduced values below this bound.
- Public quotient endpoints have magnitude at most 4097. Large signed values are reduced once per curve; the prime sieve then uses only small signed integer operations (`p <= 61`).
- **The final cubes do not fit 128 bits.** That rare path uses `num-bigint`, integer square root and a fresh exact cube identity check. There is no floating-point rejection or truncated integer fallback.

Rust release builds retain overflow checks. A bound violation aborts the task; it cannot produce negative coverage. The only intentional wrapping operations are the documented modulo-`2^64` Montgomery inverse/reduction operations.

## Montgomery multiplication

A separately tested Montgomery path supports **odd moduli below `2^63`**, including composite moduli. Even moduli use ordinary wide multiplication/reduction. The norm root check needs only two modular multiplications per D, so conversion/setup costs can outweigh savings. The benchmark compares both paths; ordinary reduction remains the default rather than assuming Montgomery is automatically faster. The small-prime sieve uses precomputed residue masks, not Montgomery multiplication.

## Measured speed

The [567-task matched benchmark](../research/benchmarks/native-wasm-2026-09-11.json) measured median 2.340 s in Python and 0.116 s in native Rust (**20.2×**), and 1.227 s in JavaScript versus 0.237 s in WASM (**5.2×**, Node on this Mac). All receipts matched. Three warm rounds follow one discarded warmup. Montgomery was slightly slower overall in these measurements, so remains optional. This includes empty and curve-bearing tasks, 79,374 curves and 218 final square tests. Process startup/JSON are included for native; banking, coverage fetches and server verification are not.

## Evidence and limits

Run `cargo test --manifest-path native/Cargo.toml --locked`, then `python -m unittest discover -s tests -p test_native_kernel.py` and the WASM gate above. Tests include all 243 frozen boundary tasks, 648 seeded random tasks, invalid descriptor rejection, 20,000 Montgomery comparisons, known positive curves, a k=3 identity whose cubes exceed 128 bits, and a complete spawned-runner checkpoint/bank round trip. Fixtures create no public submissions or leaderboard credit.

A language speedup is not a discovery-probability multiplier. The reviewer is right about selective coverage and unvalidated discovery prediction. Their claimed 100–1,000× deficit and “minutes” equivalence require a matched workload: our logical quotient positions include positions rejected without enumeration, and do not measure zcubes sieve instructions. Likewise, a bounded negative receipt proves a negative statement about its exact task, not a new global height bound.

Reference sources: [Booker–Sutherland implementation](https://github.com/AndrewVSutherland/SumsOfThreeCubes), [64-bit Montgomery arithmetic](https://github.com/AndrewVSutherland/SumsOfThreeCubes/blob/main/m64.h), and [their paper](https://arxiv.org/abs/2007.01209). The published project describes Charity Engine's volunteer PCs; this review did not establish the reviewer's claim of a later GPU implementation.
